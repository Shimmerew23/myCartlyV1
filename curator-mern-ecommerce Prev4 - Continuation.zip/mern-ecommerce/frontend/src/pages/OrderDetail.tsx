import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Package, Truck, CheckCircle, XCircle, Clock, RotateCcw, ArrowLeft, MapPin, CreditCard } from 'lucide-react';
import api from '@/api/axios';
import { Order } from '@/types';
import toast from 'react-hot-toast';
import { Helmet } from 'react-helmet-async';

const STATUS_TIMELINE = ['pending','confirmed','processing','shipped','out_for_delivery','delivered'];
const STATUS_ICONS: Record<string, any> = { pending: Clock, confirmed: CheckCircle, processing: Package, shipped: Truck, delivered: CheckCircle, cancelled: XCircle };

const OrderDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [returning, setReturning] = useState(false);

  useEffect(() => {
    api.get(`/orders/${id}`).then(({ data }) => setOrder(data.data)).catch(() => {}).finally(() => setLoading(false));
  }, [id]);

  const handleReturn = async () => {
    const reason = prompt('Reason for return:');
    if (!reason) return;
    setReturning(true);
    try {
      await api.post(`/orders/${id}/return`, { reason });
      toast.success('Return request submitted!');
      const { data } = await api.get(`/orders/${id}`);
      setOrder(data.data);
    } catch (err: any) { toast.error(err.response?.data?.message || 'Return failed'); }
    setReturning(false);
  };

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-10 space-y-4">{[...Array(5)].map((_, i) => <div key={i} className="h-20 skeleton rounded-lg" />)}</div>;
  if (!order) return <div className="text-center py-20"><p className="text-outline">Order not found</p><Link to="/orders" className="btn-primary mt-4">Back to Orders</Link></div>;

  const currentStep = STATUS_TIMELINE.indexOf(order.status);
  const isCancelled = order.status === 'cancelled';

  return (
    <>
      <Helmet><title>{order.orderNumber} | The Curator</title></Helmet>
      <div className="max-w-3xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-center gap-4">
          <Link to="/orders" className="btn-ghost text-xs"><ArrowLeft size={14} /> Orders</Link>
          <div>
            <h1 className="font-headline text-2xl font-black tracking-tighter">{order.orderNumber}</h1>
            <p className="text-xs text-outline">Placed {new Date(order.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
        </div>

        {/* Status Timeline */}
        {!isCancelled && (
          <div className="bg-white rounded-lg border border-outline-variant/20 p-6">
            <h2 className="font-headline font-black text-sm uppercase tracking-wider mb-5">Order Status</h2>
            <div className="flex items-center">
              {STATUS_TIMELINE.map((s, i) => {
                const done = i <= currentStep;
                const active = i === currentStep;
                return (
                  <div key={s} className="flex items-center flex-1 last:flex-none">
                    <div className="flex flex-col items-center gap-1">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${done ? 'bg-primary-900 text-white' : 'bg-surface-container text-outline'}`}>
                        {done ? <CheckCircle size={14} /> : i + 1}
                      </div>
                      <span className={`text-[10px] text-center capitalize hidden sm:block ${active ? 'text-primary-900 font-bold' : done ? 'text-on-surface' : 'text-outline'}`}>{s.replace(/_/g,' ')}</span>
                    </div>
                    {i < STATUS_TIMELINE.length - 1 && <div className={`flex-1 h-0.5 mx-1 ${i < currentStep ? 'bg-primary-900' : 'bg-surface-container'}`} />}
                  </div>
                );
              })}
            </div>
            {order.tracking?.trackingNumber && (
              <div className="mt-4 p-3 bg-primary-50 rounded-md">
                <p className="text-xs font-semibold text-primary-900">Tracking: <span className="font-normal">{order.tracking.carrier} — {order.tracking.trackingNumber}</span></p>
                {order.tracking.estimatedDelivery && <p className="text-xs text-primary-700 mt-0.5">Est. delivery: {new Date(order.tracking.estimatedDelivery).toLocaleDateString()}</p>}
              </div>
            )}
          </div>
        )}

        {isCancelled && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-sm font-semibold text-error flex items-center gap-2"><XCircle size={14} /> Order Cancelled</p>
            {order.cancellationReason && <p className="text-xs text-red-600 mt-1">Reason: {order.cancellationReason}</p>}
          </div>
        )}

        {/* Items */}
        <div className="bg-white rounded-lg border border-outline-variant/20 overflow-hidden">
          <div className="px-5 py-4 border-b border-outline-variant/10"><h2 className="font-headline font-black text-sm uppercase tracking-wider">Items ({order.items.length})</h2></div>
          <div className="divide-y divide-outline-variant/10">
            {order.items.map((item, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-4">
                <div className="w-14 h-14 rounded-md overflow-hidden bg-surface-low flex-shrink-0">
                  <img src={item.image || '/placeholder.jpg'} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-on-surface">{item.name}</p>
                  {item.variant && <p className="text-xs text-outline">{item.variant.name}: {item.variant.value}</p>}
                  <p className="text-xs text-outline">Qty: {item.quantity} × ${item.price.toFixed(2)}</p>
                </div>
                <span className="font-bold text-on-surface text-sm">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Info row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white rounded-lg border border-outline-variant/20 p-5">
            <h3 className="font-headline font-black text-xs uppercase tracking-wider mb-3 flex items-center gap-2"><MapPin size={13} /> Shipping Address</h3>
            <p className="text-sm font-semibold text-on-surface">{order.shippingAddress.name}</p>
            <p className="text-sm text-outline">{order.shippingAddress.street}</p>
            <p className="text-sm text-outline">{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
            <p className="text-sm text-outline">{order.shippingAddress.country}</p>
          </div>
          <div className="bg-white rounded-lg border border-outline-variant/20 p-5">
            <h3 className="font-headline font-black text-xs uppercase tracking-wider mb-3 flex items-center gap-2"><CreditCard size={13} /> Payment</h3>
            <p className="text-sm text-on-surface capitalize">{order.paymentMethod}</p>
            <span className={`badge mt-1 ${order.paymentStatus === 'paid' ? 'badge-success' : order.paymentStatus === 'failed' ? 'badge-error' : 'badge-warning'}`}>{order.paymentStatus}</span>
            {order.paidAt && <p className="text-xs text-outline mt-1">Paid: {new Date(order.paidAt).toLocaleDateString()}</p>}
          </div>
        </div>

        {/* Price breakdown */}
        <div className="bg-white rounded-lg border border-outline-variant/20 p-5 space-y-2 text-sm">
          <h3 className="font-headline font-black text-xs uppercase tracking-wider mb-3">Price Breakdown</h3>
          <div className="flex justify-between text-on-surface-variant"><span>Subtotal</span><span>${order.subtotal.toFixed(2)}</span></div>
          {order.discountAmount > 0 && <div className="flex justify-between text-success"><span>Discount</span><span>-${order.discountAmount.toFixed(2)}</span></div>}
          <div className="flex justify-between text-on-surface-variant"><span>Shipping</span><span>{order.shippingCost === 0 ? 'Free' : `$${order.shippingCost.toFixed(2)}`}</span></div>
          <div className="flex justify-between text-on-surface-variant"><span>Tax</span><span>${order.taxAmount.toFixed(2)}</span></div>
          <div className="flex justify-between font-bold text-on-surface text-base border-t border-outline-variant/10 pt-2"><span>Total</span><span>${order.totalPrice.toFixed(2)}</span></div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-3">
          {order.status === 'delivered' && (
            <button onClick={handleReturn} disabled={returning} className="btn-secondary text-xs">
              {returning ? <div className="w-4 h-4 border-2 border-primary-900 border-t-transparent rounded-full animate-spin" /> : <><RotateCcw size={13} /> Request Return</>}
            </button>
          )}
          <Link to="/products" className="btn-ghost text-xs">Continue Shopping</Link>
        </div>
      </div>
    </>
  );
};

export default OrderDetailPage;
