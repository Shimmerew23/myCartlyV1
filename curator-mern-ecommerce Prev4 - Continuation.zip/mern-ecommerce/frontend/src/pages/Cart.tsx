import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Tag, X } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store';
import { fetchCart, updateCartItem, removeFromCart, clearCart, applyCoupon } from '@/store/slices/cartSlice';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { Helmet } from 'react-helmet-async';

const CartPage = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { items, subtotal, itemCount, coupon, isLoading } = useAppSelector((s) => s.cart);
  const { isAuthenticated } = useAppSelector((s) => s.auth);
  const [couponCode, setCouponCode] = useState('');
  const [applyingCoupon, setApplyingCoupon] = useState(false);

  useEffect(() => { if (isAuthenticated) dispatch(fetchCart()); }, [isAuthenticated, dispatch]);

  const discount = coupon
    ? coupon.discountType === 'percentage' ? subtotal * (coupon.discountValue / 100) : coupon.discountValue
    : 0;
  const shipping = subtotal > 100 ? 0 : 9.99;
  const tax = Math.round(subtotal * 0.1 * 100) / 100;
  const total = subtotal - discount + shipping + tax;

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setApplyingCoupon(true);
    await dispatch(applyCoupon(couponCode));
    setApplyingCoupon(false);
    setCouponCode('');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <ShoppingBag size={48} className="text-outline mx-auto mb-4" />
        <h2 className="font-headline text-2xl font-black mb-2">Sign in to view your cart</h2>
        <p className="text-outline mb-6">Your cart is saved across devices when you're signed in</p>
        <Link to="/login" className="btn-primary">Sign In</Link>
      </div>
    );
  }

  return (
    <>
      <Helmet><title>Cart | The Curator</title></Helmet>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <h1 className="font-headline text-3xl font-black tracking-tighter mb-8">
          Shopping Cart
          {itemCount > 0 && <span className="ml-3 text-lg font-normal text-outline">({itemCount} item{itemCount !== 1 ? 's' : ''})</span>}
        </h1>

        {items.length === 0 ? (
          <div className="text-center py-24">
            <ShoppingBag size={56} className="text-outline mx-auto mb-6" />
            <h2 className="font-headline text-2xl font-black mb-2">Your cart is empty</h2>
            <p className="text-outline mb-8">Add some products to get started</p>
            <Link to="/products" className="btn-primary">Browse Products</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => (
                <motion.div key={item._id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex gap-4 p-4 bg-white rounded-lg border border-outline-variant/20 shadow-card">
                  <Link to={`/products/${item.product?.slug}`} className="w-24 h-24 flex-shrink-0 bg-surface-low rounded-md overflow-hidden">
                    <img src={item.product?.images?.[0]?.url || '/placeholder.jpg'} alt={item.product?.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <Link to={`/products/${item.product?.slug}`} className="font-semibold text-sm text-on-surface hover:text-primary-900 transition-colors line-clamp-2">{item.product?.name}</Link>
                        {item.variant && <p className="text-xs text-outline mt-0.5">{item.variant.name}: {item.variant.value}</p>}
                        <p className="text-xs text-outline mt-0.5">${item.price.toFixed(2)} each</p>
                      </div>
                      <button onClick={() => dispatch(removeFromCart(item._id))} className="text-outline hover:text-error transition-colors p-1 flex-shrink-0"><Trash2 size={15} /></button>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center border border-outline-variant/30 rounded-md overflow-hidden">
                        <button onClick={() => dispatch(updateCartItem({ itemId: item._id, quantity: item.quantity - 1 }))} disabled={item.quantity <= 1} className="w-8 h-8 flex items-center justify-center hover:bg-surface-container transition-colors disabled:opacity-40"><Minus size={12} /></button>
                        <span className="w-10 text-center text-sm font-semibold">{item.quantity}</span>
                        <button onClick={() => dispatch(updateCartItem({ itemId: item._id, quantity: item.quantity + 1 }))} className="w-8 h-8 flex items-center justify-center hover:bg-surface-container transition-colors"><Plus size={12} /></button>
                      </div>
                      <span className="font-bold text-on-surface">${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
              <div className="flex justify-end">
                <button onClick={() => dispatch(clearCart())} className="btn-ghost text-xs text-error hover:bg-red-50"><X size={14} /> Clear Cart</button>
              </div>
            </div>

            {/* Summary */}
            <div className="space-y-4">
              {/* Coupon */}
              <div className="bg-white rounded-lg border border-outline-variant/20 p-5">
                <h3 className="font-headline font-black text-sm uppercase tracking-wider mb-3 flex items-center gap-2"><Tag size={14} /> Coupon Code</h3>
                {coupon ? (
                  <div className="flex items-center justify-between bg-success/10 border border-success/20 rounded-md px-3 py-2">
                    <span className="text-xs font-bold text-success">{coupon.code} — {coupon.discountType === 'percentage' ? `${coupon.discountValue}% off` : `$${coupon.discountValue} off`}</span>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input value={couponCode} onChange={(e) => setCouponCode(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === 'Enter' && handleApplyCoupon()} placeholder="COUPON CODE" className="flex-1 input-box text-xs uppercase" />
                    <button onClick={handleApplyCoupon} disabled={applyingCoupon || !couponCode} className="btn-secondary text-xs px-4 disabled:opacity-50">
                      {applyingCoupon ? <div className="w-4 h-4 border-2 border-primary-900 border-t-transparent rounded-full animate-spin" /> : 'Apply'}
                    </button>
                  </div>
                )}
              </div>

              {/* Order Summary */}
              <div className="bg-white rounded-lg border border-outline-variant/20 p-5 space-y-3">
                <h3 className="font-headline font-black text-sm uppercase tracking-wider mb-4">Order Summary</h3>
                <div className="flex justify-between text-sm text-on-surface-variant"><span>Subtotal ({itemCount} items)</span><span>${subtotal.toFixed(2)}</span></div>
                {discount > 0 && <div className="flex justify-between text-sm text-success"><span>Discount</span><span>-${discount.toFixed(2)}</span></div>}
                <div className="flex justify-between text-sm text-on-surface-variant"><span>Shipping</span><span className={shipping === 0 ? 'text-success font-semibold' : ''}>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span></div>
                <div className="flex justify-between text-sm text-on-surface-variant"><span>Tax (10%)</span><span>${tax.toFixed(2)}</span></div>
                <div className="flex justify-between font-bold text-on-surface pt-3 border-t border-outline-variant/20 text-base"><span>Total</span><span>${total.toFixed(2)}</span></div>
                {shipping > 0 && <p className="text-xs text-outline text-center">Add ${(100 - subtotal).toFixed(2)} more for free shipping</p>}
                <button onClick={() => navigate('/checkout')} className="btn-primary w-full justify-center py-4 mt-2">Proceed to Checkout <ArrowRight size={16} /></button>
                <Link to="/products" className="btn-ghost w-full justify-center text-xs">Continue Shopping</Link>
              </div>

              {/* Safe checkout badges */}
              <div className="text-center text-xs text-outline space-y-1">
                <p className="font-semibold">🔒 Secure Checkout</p>
                <p>256-bit SSL encryption · Stripe payments</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default CartPage;
