import { useEffect, useState, useCallback } from 'react';
import { Search, ChevronDown, RefreshCw, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '@/api/axios';
import { Order } from '@/types';
import toast from 'react-hot-toast';
import { Helmet } from 'react-helmet-async';

const STATUS_STYLES: Record<string, string> = { pending:'badge-warning',confirmed:'badge-info',processing:'badge-info',shipped:'badge-primary',delivered:'badge-success',cancelled:'badge-error',return_requested:'badge-warning',returned:'badge-neutral',refunded:'badge-neutral' };
const PAYMENT_STYLES: Record<string, string> = { paid:'badge-success',pending:'badge-warning',failed:'badge-error',refunded:'badge-neutral' };

const AdminOrders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', status: '', paymentStatus: '', sort: '-createdAt' });
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetch = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const params: any = { page, limit: 20, ...filters };
      Object.keys(params).forEach((k) => { if (!params[k]) delete params[k]; });
      const { data } = await api.get('/admin/orders', { params });
      setOrders(data.data); setPagination(data.pagination);
    } catch { toast.error('Failed to load orders'); } finally { setLoading(false); }
  }, [filters]);

  useEffect(() => { fetch(1); }, [filters]);

  const handleStatusUpdate = async (orderId: string, status: string) => {
    setUpdatingId(orderId);
    try { await api.put(`/orders/${orderId}/status`, { status }); toast.success('Status updated'); fetch(pagination.page); } catch (err: any) { toast.error(err.response?.data?.message || 'Update failed'); }
    setUpdatingId(null);
  };

  return (
    <>
      <Helmet><title>Orders | Admin</title></Helmet>
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div><h1 className="font-headline text-2xl font-black tracking-tighter">Orders</h1><p className="text-sm text-outline mt-0.5">{pagination.total.toLocaleString()} total</p></div>
          <button onClick={() => fetch(1)} className="btn-ghost text-xs"><RefreshCw size={14} /> Refresh</button>
        </div>
        <div className="card p-4 flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-outline" /><input value={filters.search} onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))} placeholder="Search order number..." className="w-full pl-9 pr-3 py-2 text-sm bg-surface-low border border-transparent rounded-md focus:outline-none focus:border-outline-variant" /></div>
          {[{ key: 'status', options: [['','All Status'],['pending','Pending'],['confirmed','Confirmed'],['shipped','Shipped'],['delivered','Delivered'],['cancelled','Cancelled']] }, { key: 'paymentStatus', options: [['','All Payment'],['paid','Paid'],['pending','Pending'],['failed','Failed']] }, { key: 'sort', options: [['-createdAt','Newest'],['-totalPrice','Highest'],['totalPrice','Lowest']] }].map(({ key, options }) => (
            <div key={key} className="relative">
              <select value={(filters as any)[key]} onChange={(e) => setFilters((f) => ({ ...f, [key]: e.target.value }))} className="appearance-none pl-3 pr-8 py-2 text-sm bg-surface-low border border-transparent rounded-md focus:outline-none focus:border-outline-variant cursor-pointer">{options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
              <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-outline pointer-events-none" />
            </div>
          ))}
        </div>
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
              <tbody>
                {loading ? [...Array(8)].map((_, i) => <tr key={i}>{[...Array(8)].map((_, j) => <td key={j}><div className="h-4 skeleton rounded w-20" /></td>)}</tr>)
                  : orders.length === 0 ? <tr><td colSpan={8} className="text-center py-12 text-outline">No orders found</td></tr>
                  : orders.map((order) => (
                  <tr key={order._id}>
                    <td><p className="font-semibold text-xs">{order.orderNumber}</p></td>
                    <td><p className="text-xs font-medium">{(order.user as any)?.name}</p><p className="text-xs text-outline">{(order.user as any)?.email}</p></td>
                    <td><span className="text-sm">{order.items.length}</span></td>
                    <td><span className="font-bold text-sm">${order.totalPrice.toFixed(2)}</span></td>
                    <td><span className={`badge ${PAYMENT_STYLES[order.paymentStatus] || 'badge-neutral'}`}>{order.paymentStatus}</span></td>
                    <td>
                      <select value={order.status} onChange={(e) => handleStatusUpdate(order._id, e.target.value)} disabled={updatingId === order._id} className={`badge cursor-pointer border-0 appearance-none font-semibold text-xs ${STATUS_STYLES[order.status] || 'badge-neutral'} pr-4`}>
                        {['pending','confirmed','processing','shipped','out_for_delivery','delivered','cancelled'].map((s) => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
                      </select>
                    </td>
                    <td><span className="text-xs text-outline">{new Date(order.createdAt).toLocaleDateString()}</span></td>
                    <td>
                      <Link to={`/orders/${order._id}`} className="w-7 h-7 flex items-center justify-center rounded hover:bg-surface-container transition-colors text-outline hover:text-on-surface"><Eye size={13} /></Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {pagination.pages > 1 && (
            <div className="flex justify-between items-center px-6 py-3 border-t border-outline-variant/10">
              <p className="text-xs text-outline">Page {pagination.page} of {pagination.pages}</p>
              <div className="flex gap-1"><button onClick={() => fetch(pagination.page - 1)} disabled={pagination.page <= 1} className="btn-ghost text-xs disabled:opacity-40">← Prev</button><button onClick={() => fetch(pagination.page + 1)} disabled={pagination.page >= pagination.pages} className="btn-ghost text-xs disabled:opacity-40">Next →</button></div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default AdminOrders;
